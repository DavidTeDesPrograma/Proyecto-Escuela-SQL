package com.mycompany.guia5;

import javax.swing.JOptionPane;

public class ListaEstudiantes {
    public static void main(String[] args) {
        concatenarNombres();
    }

    public static void concatenarNombres() {
        String nombresConcatenados = "";
        
        while (true) {
            String nombre = JOptionPane.showInputDialog("Ingrese el nombre del estudiante (o deje vacío para terminar):");
            
            // Salir del bucle si el usuario deja el campo vacío
            if (nombre == null || nombre.isEmpty()) {
                break;
            }
            
            // Concatenar el nombre ingresado al resultado
            nombresConcatenados += nombre + "\n";
        }

        // Mostrar los nombres concatenados en un cuadro de diálogo
        JOptionPane.showMessageDialog(null, "Nombres de los estudiantes:\n" + nombresConcatenados);
    }
}