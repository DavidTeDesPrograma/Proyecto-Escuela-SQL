/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.guia5;


 import java.util.Scanner;
public class PotenciaRaizCuadrada {
    public static void main(String[] args) {
        // Calcular la potencia
        double base = 2;
        double exponente = 3;
        double potencia = Math.pow(base, exponente);
        System.out.println(base + " elevado a la potencia " + exponente + " es: " + potencia);

        // Calcular la raíz cuadrada
        double numero = 16;
        double raizCuadrada = Math.sqrt(numero);
        System.out.println("La raíz cuadrada de " + numero + " es: " + raizCuadrada);
    }
    
}