/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.numerosamigos;

/**
 *
 * @author David
 */
import javax.swing.JOptionPane;

public class NumerosAmigos {
    public static void main(String[] args) {
        // Solicitar al usuario el rango
        String inputInicio = JOptionPane.showInputDialog("Ingrese el inicio del rango:");
        String inputFin = JOptionPane.showInputDialog("Ingrese el fin del rango:");

        // Convertir la entrada a enteros
        int inicio = Integer.parseInt(inputInicio);
        int fin = Integer.parseInt(inputFin);

        // Calcular y mostrar números amigos dentro del rango
        StringBuilder resultado = new StringBuilder("Números amigos dentro del rango [" + inicio + ", " + fin + "]:\n");
        for (int i = inicio; i <= fin; i++) {
            int amigo = calcularAmigo(i);
            if (amigo > i && amigo <= fin && calcularAmigo(amigo) == i) {
                resultado.append("(").append(i).append(", ").append(amigo).append(")\n");
            }
        }

        // Mostrar el resultado
        JOptionPane.showMessageDialog(null, resultado.toString(), "Números Amigos", JOptionPane.INFORMATION_MESSAGE);
    }

    // Método para calcular la suma de los divisores propios de un número
    public static int sumaDivisoresPropios(int numero) {
        int suma = 1; // Suma siempre incluye al divisor 1
        for (int i = 2; i <= Math.sqrt(numero); i++) {
            if (numero % i == 0) {
                suma += i;
                if (i != numero / i) { // Evitar contar el divisor repetido si el número es un cuadrado perfecto
                    suma += numero / i;
                }
            }
        }
        return suma;
    }

    // Método para calcular el amigo de un número
    public static int calcularAmigo(int numero) {
        return sumaDivisoresPropios(numero) - numero;
    }
}