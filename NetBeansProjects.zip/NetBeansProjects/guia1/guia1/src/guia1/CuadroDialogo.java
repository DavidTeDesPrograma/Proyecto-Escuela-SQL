import javax.swing. JOptionPane;
public class CuadroDialogo {
 
public static void main(String[] args) {

JOptionPane.showMessageDialog(null, "Bienvenido a Escuela Informatica infotep");
System.exit(0);
 }
}