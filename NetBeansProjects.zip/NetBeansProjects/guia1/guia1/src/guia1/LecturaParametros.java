
public class LecturaParametros {
    public static void main (String []args){
    
        String[] parametro = new String[3];
    for(int i = 0; parametro <= 2 ; i++){    
    System.out.println("Parametro 1: "+parametro[0]+"\n");
    System.out.println("Parametro 1: "+parametro[1]);
    }
    
    }
    
}
