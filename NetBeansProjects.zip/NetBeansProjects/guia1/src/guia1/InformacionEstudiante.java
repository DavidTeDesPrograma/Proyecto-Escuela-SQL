/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package guia1;

/**
 *
 * @author David
 */
import java.util.Scanner;

public class InformacionEstudiante {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Solicitar información
        System.out.println("Por favor, ingrese su nombre:");
        String nombres = scanner.nextLine();

        System.out.println("Por favor, ingrese su apellido:");
        String apellidos = scanner.nextLine();

        System.out.println("Por favor, ingrese su edad:");
        int edad = scanner.nextInt();
        scanner.nextLine(); // Consumir el salto de línea pendiente después de nextInt()

        System.out.println("Por favor, ingrese su carrera:");
        String carrera = scanner.nextLine();

        // Imprimir información en consola
        System.out.println("\nInformación Básica:");
        System.out.println("Nombres: " + nombres);
        System.out.println("Apellidos: " + apellidos);
        System.out.println("Edad: " + edad);
        System.out.println("Carrera: " + carrera);

        scanner.close(); // Cerrar el scanner al finalizar
    }
}