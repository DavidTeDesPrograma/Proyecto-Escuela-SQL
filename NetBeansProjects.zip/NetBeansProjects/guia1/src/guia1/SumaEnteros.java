/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package guia1;


import javax.swing.JOptionPane;

public class SumaEnteros {
    public static void main(String[] args) {
        String primerNumero;
        String segundoNumero;
        int numero1;
        int numero2;
        int suma;

        primerNumero = JOptionPane.showInputDialog("Digite el primer numero");
        // Validar si el primer número es negativo
        while (!esNumeroEnteroValido(primerNumero)) {
            primerNumero = JOptionPane.showInputDialog("El número debe ser positivo. Digite el primer numero nuevamente");
        }

        segundoNumero = JOptionPane.showInputDialog("Digite el segundo numero");
        // Validar si el segundo número es negativo
        while (!esNumeroEnteroValido(segundoNumero)) {
            segundoNumero = JOptionPane.showInputDialog("El número debe ser positivo. Digite el segundo numero nuevamente");
        }

        numero1 = Integer.parseInt(primerNumero);
        numero2 = Integer.parseInt(segundoNumero);
        suma = numero1 + numero2;
        JOptionPane.showMessageDialog(null, "La suma es: " + suma, "Resultado", JOptionPane.PLAIN_MESSAGE);
        System.exit(0);
    }

    // Método para validar si una cadena representa un número entero positivo
    private static boolean esNumeroEnteroValido(String numero) {
        try {
            int num = Integer.parseInt(numero);
            return num >= 0;
        } catch (NumberFormatException e) {
            return false;
        }
    }
}