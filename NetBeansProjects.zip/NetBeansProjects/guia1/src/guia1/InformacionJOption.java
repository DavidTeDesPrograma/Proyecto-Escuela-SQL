/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package guia1;

import javax.swing.JOptionPane;
public class InformacionJOption {
    static public void main (String[] args){
     String nombre = JOptionPane.showInputDialog("Ingrese el nombre ");
     String apellido = JOptionPane.showInputDialog("Ingrese el Apellido");
     String edadStr = JOptionPane.showInputDialog("Por favor, ingrese su edad:");
     int edad = Integer.parseInt(edadStr);
     String carrera = JOptionPane.showInputDialog("Ingrese la carrera");
     
      
     
        StringBuilder mensaje = new StringBuilder();
        
        mensaje.append("Información Básica:\n");
        mensaje.append("Nombres: ").append(nombre).append("\n");
        mensaje.append("Apellidos: ").append(apellido).append("\n");
        mensaje.append("Edad: ").append(edad).append("\n");
        mensaje.append("Carrera: ").append(carrera);
        
    JOptionPane.showMessageDialog(null, mensaje.toString(), "Información Básica", JOptionPane.INFORMATION_MESSAGE);
    }
    
    
}
