/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.guia4;

/**
 *
 * @author David
 */
import javax.swing.JOptionPane;

public class NumerosPrimos {
    public static void main(String[] args) {
        // Solicitar al usuario que ingrese un número entero positivo
        String input = JOptionPane.showInputDialog("Por favor, ingrese un número entero positivo:");
        
        // Convertir la entrada a un entero
        int numero = Integer.parseInt(input);

        // Verificar si el número es primo
        boolean esPrimo = esPrimo(numero);

        // Mostrar el resultado
        if (esPrimo) {
            JOptionPane.showMessageDialog(null, numero + " es un número primo.", "Resultado", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, numero + " no es un número primo.", "Resultado", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    // Método para verificar si un número es primo
    public static boolean esPrimo(int numero) {
        if (numero <= 1) {
            return false;
        }
        for (int i = 2; i <= Math.sqrt(numero); i++) {
            if (numero % i == 0) {
                return false;
            }
        }
        return true;
    }
}