
package com.mycompany.guia6;

import java.util.Scanner;
public class NotaEstudiante {

    public static void main(String[] args) {

       
         Scanner scanner = new Scanner(System.in);

        // Definir las variables
        String[] materias = {"Español", "Matemáticas", "Sociales", "Naturales"};
        int[][] notas = new int[4][5];
        int[] promedios = new int[4];

        // Solicitar las notas al usuario
        for (int i = 0; i < materias.length; i++) {
            for (int j = 0; j < notas[i].length; j++) {
                System.out.print("Ingrese la nota " + (j + 1) + " de " + materias[i] + ": ");
                notas[i][j] = scanner.nextInt();
            }
        }

        // Calcular el promedio de cada materia
        for (int i = 0; i < materias.length; i++) {
            int promedio = 0;
            for (int j = 0; j < notas[i].length; j++) {
                promedio += notas[i][j];
            }
            promedios[i] = promedio / notas[i].length;
        }

        // Mostrar el cuadro de notas
        System.out.println("----------------------------------------");
        System.out.println("Cuadro de notas");
        System.out.println("----------------------------------------");

        System.out.printf("%10s%-15s", "", "Materia");
        for (int i = 0; i < notas[0].length; i++) {
            System.out.printf("%-15s", "Nota " + (i + 1));
        }
        System.out.println();

        System.out.println("----------------------------------------");

        for (int i = 0; i < materias.length; i++) {
            System.out.printf("%-15s", materias[i]);
            for (int j = 0; j < notas[i].length; j++) {
                System.out.printf("%-15s", " " + notas[i][j]);
            }
            System.out.println();
        }

        System.out.println("----------------------------------------");

        System.out.printf("%-15s", "Materia");
        System.out.printf("%-15s", "Promedio");
        System.out.println();

        System.out.println("----------------------------------------");

        for (int i = 0; i < materias.length; i++) {
            System.out.printf("%-15s", materias[i]);
            System.out.printf("%-15s", " " + promedios[i]);
            System.out.println();
        }

        System.out.println("----------------------------------------");

    }

}